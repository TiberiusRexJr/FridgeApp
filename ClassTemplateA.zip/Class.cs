﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $rootnamespace$
{
    class A
    {
        #region Variables
        #endregion
        #region Properties
        #endregion
        #region Implementations
        #endregion
        #region Constructor

        #endregion
        #region Functions
        #endregion
    }
}
